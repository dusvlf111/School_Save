import math
print('Chapter 2 연습문제 4번 p70')
NUM = int(input ('반지름을 입력하세요:     '))
print('반지름이 {} 인 원의 넓이 = '.format(NUM), NUM*math.pi)

input()
