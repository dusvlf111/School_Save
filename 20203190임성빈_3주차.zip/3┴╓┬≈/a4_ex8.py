import turtle
t = turtle.Turtle()
t.shape("turtle")

tx = -160, 0, 160 , -80, 80
ty = 0, 0, 0 , -80, -80
tcolor = 'blue', 'black', 'red','yellow', 'green'
tzip = list(zip(tx, ty))
t.pensize(5)

for i in range(len(tzip)):
    t.color(tcolor[i])
    t.penup()
    t.goto(tzip[i])
    t.pendown()
    t.circle(75)

turtle.done()