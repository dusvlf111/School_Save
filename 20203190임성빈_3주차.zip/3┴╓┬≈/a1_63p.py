name = input('이름을 입력하세요:    ')

print(name,'씨, 안녕하세요? \n 파이썬에 오신걸 환영합니다')


NUM1 = int(input('첫 번째 정수를 입력하시오:    '))
NUM2 = int(input('두 번째 정수를 입력하시오:    '))
print(NUM1,'과',NUM2,'의 합은', NUM1+NUM2,'입니다.')

input()