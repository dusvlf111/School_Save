import turtle
t= turtle.Turtle()
t.shape("turtle")

size = int(turtle.textinput('정수입력', 'Enter the size of the house:  '))
X = turtle.numinput ('아무 의미 없음', '최소10 최대300 까지', None, 100,300)

t.color("red")
t.begin_fill()

t.left(60)
t.forward(size)

t.right(120)
t.forward(size)

t.right(30)
t.forward(size)
t.end_fill()

t.color("blue")
t.begin_fill()

for i in range(3):
    t.right(90)
    t.forward(size)
    
t.end_fill()

turtle.done()