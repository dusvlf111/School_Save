#include <iostream>

int main() {
    std::cout << "hello world";
    return 0;
}